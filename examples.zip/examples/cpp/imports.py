# tag::import1[]
from PyQt5.QtWidgets import *

# end::import1[]

# tag::import2[]
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QHBoxLayout

# end::import2[]

# tag::import3[]
from PyQt5 import QtWidgets

# end::import3[]

InfiniteLine
============

.. autoclass:: pyqtgraph.InfiniteLine
    :members:

    .. automethod:: pyqtgraph.InfiniteLine.__init__


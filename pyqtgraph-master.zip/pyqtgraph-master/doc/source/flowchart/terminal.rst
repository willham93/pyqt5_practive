flowchart.Terminal
==================

.. autoclass:: pyqtgraph.flowchart.Terminal
    :members:

    .. automethod:: pyqtgraph.flowchart.Terminal.__init__


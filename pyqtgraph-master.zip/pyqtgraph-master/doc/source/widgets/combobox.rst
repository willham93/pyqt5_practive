ComboBox
========

.. autoclass:: pyqtgraph.ComboBox
    :members:

    .. automethod:: pyqtgraph.ComboBox.__init__


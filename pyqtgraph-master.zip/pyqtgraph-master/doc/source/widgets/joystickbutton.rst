JoystickButton
==============

.. autoclass:: pyqtgraph.JoystickButton
    :members:

    .. automethod:: pyqtgraph.JoystickButton.__init__


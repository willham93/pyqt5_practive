ParameterTree API Reference
===========================

Also see the 'parametertree' example included with pyqtgraph

Contents:

.. toctree::
    :maxdepth: 2

    parameter
    parametertree
    parametertypes
    parameteritem

